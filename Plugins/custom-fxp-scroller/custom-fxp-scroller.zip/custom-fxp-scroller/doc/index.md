Getting Started
===============

Installation
------------

```
npm install @fxp/jquery-scroller --save
```

Dev installation
----------------

### Use NPM

```
npm install
```

### Use Webpack Encore

```
$ encore dev-server --port 9000
```

Open the URL `http://localhost:9000/build` in your browser.
